import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import Dropzone from 'react-dropzone';
import Plot from 'react-plotly.js';
import './App.css';

function App() {
  const [uploadedFile, setUploadedFile] = useState(null);
  const [filteredData, setFilteredData] = useState(null);

  const handleFileUpload = (acceptedFiles) => {
    const file = acceptedFiles[0];
    setUploadedFile(file);

    const reader = new FileReader();
    reader.onload = function (e) {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const firstSheet = workbook.SheetNames[0];
      const excelData = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet]);

      const filteredData = excelData.filter((item) => !Object.values(item).every((value) => value === null));

      setFilteredData(filteredData);
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div className="container">
      <h1 className="title">
        <span style={{ color: 'black' }}>Project</span>
      </h1>
      <div className="left-content">
        <h2>File Upload and Data Visualization</h2>
        <p>
          Upload an Excel file below to visualize its data in a line graph.
        </p>
      </div>
      <Dropzone onDrop={handleFileUpload}>
        {({ getRootProps, getInputProps }) => (
          <div {...getRootProps()} className="dropzone">
            <input {...getInputProps()} />
            <p>Insert file</p>
            {uploadedFile && (
              <p className="file-info">
                <b>Your File is being analyzed:</b> {uploadedFile.name}
              </p>
            )}
          </div>
        )}
      </Dropzone>
      {filteredData && (
        <div className="chart-item">
          <h2>Line Graph</h2>
          <Plot
            data={[
              {
                x: Object.keys(filteredData[0]),
                y: filteredData.map((item) => Object.values(item)[0]), // Assuming the first column is the data for the line graph
                type: 'scatter',
                mode: 'lines+markers',
              },
            ]}
            layout={{ title: 'Line Graph' }}
          />
        </div>
      )}
    </div>
  );
}

export default App;
